# marketplace-kit


## Versioning

This project uses [Semantic versioning](https://semver.org/).

When using [`npm version`](https://docs.npmjs.com/cli/version) command please keep that in mind.

## Publish

    npm version patch
    
    git push --tags
       
    npm publish
